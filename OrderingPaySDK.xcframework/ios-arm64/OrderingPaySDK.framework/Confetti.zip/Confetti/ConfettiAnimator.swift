//
//  ConfettiAnimator.swift
//  MyFawry
//
//  Created by Ahmed Hussien on 28/07/2021.
//  Copyright © 2021 Mattemark. All rights reserved.
//

import UIKit

class ConfettiAnimator {
    
    private var bounds: CGRect
    
    init(bounds: CGRect) {
        self.bounds = bounds
    }
    
    private var foregroundConfettiLayer: CAEmitterLayer {
        createConfettiLayer()
    }
    private var backgroundConfettiLayer: CAEmitterLayer {
        let emitterLayer = createConfettiLayer()
        for emitterCell in emitterLayer.emitterCells ?? [] {
            emitterCell.scale = 0.5
        }
        emitterLayer.opacity = 0.5
        emitterLayer.speed = 0.95
        return emitterLayer
    }
    private lazy var confettiTypes: [ConfettiType] = {
        var confettiColors: [UIColor] = [#colorLiteral(red: 0.1098039216, green: 0.1843137255, blue: 0.8509803922, alpha: 1), #colorLiteral(red: 0.8, green: 0.01568627451, blue: 0.01960784314, alpha: 1), #colorLiteral(red: 1, green: 0.3490196078, blue: 0.03921568627, alpha: 1)]

        // Construct a confetti type for each (position x shape x color) combination
        return ConfettiPosition.allCases.flatMap { position in
            return ConfettiShape.allCases.flatMap { shape in
                return confettiColors.map { color in
                    return ConfettiType(color: color,
                                        shape: shape,
                                        position: position)
                }
            }
        }
    }()
    
    private func createConfettiLayer() -> CAEmitterLayer {
        let emitterLayer = CAEmitterLayer()

        emitterLayer.emitterCells = createConfettiCells()
        emitterLayer.emitterPosition = CGPoint(x: bounds.midX,
                                               y: bounds.minY)
        emitterLayer.emitterSize = CGSize(width: bounds.size.width,
                                         height: 500)
        emitterLayer.emitterShape = .rectangle
        emitterLayer.frame = bounds

        emitterLayer.beginTime = CACurrentMediaTime()
        return emitterLayer
    }
    
    private func createConfettiCells() -> [CAEmitterCell] {
        return confettiTypes.map { confettiType in
            let cell = CAEmitterCell()

            cell.beginTime = 0
            cell.duration = 3
            cell.birthRate = 10
            cell.contents = confettiType.image.cgImage
            cell.emissionRange = CGFloat(Double.pi)
            cell.lifetime = 10
            cell.spin = 4
            cell.spinRange = 8
            cell.velocityRange = 100
            cell.yAcceleration = 150

             //The plan particle type allows the confetti to rotate on more than one axis, giving it an immediate three-dimensional appearance.
            cell.setValue("plane", forKey: "particleType")
            cell.setValue(Double.pi, forKey: "orientationRange")
            cell.setValue(Double.pi/2, forKey: "orientationLongitude")
            cell.setValue(Double.pi/2, forKey: "orientationLatitude")

            return cell
        }
    }
    
    
    func animate(inLayer layer: CALayer) {
        for confettiLayer in [foregroundConfettiLayer, backgroundConfettiLayer] {
            layer.addSublayer(confettiLayer)
        }
    }
}
